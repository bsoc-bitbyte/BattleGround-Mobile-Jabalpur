/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
using AIGD;
using System;
using System.ComponentModel;
using com.IvanMurzak.McpPlugin;
using com.IvanMurzak.ReflectorNet.Utils;
using com.IvanMurzak.Unity.MCP.Editor.Utils;
using UnityEditor;

namespace com.IvanMurzak.Unity.MCP.Editor.API
{
    public partial class Tool_Editor
    {
        public const string EditorApplicationSetStateToolId = "editor-application-set-state";
        [AiTool
        (
            EditorApplicationSetStateToolId,
            Title = "Editor / Application / Set State",
            IdempotentHint = true,
            Enabled = false
        )]
        [AiSkillDescription("Start / stop / pause the Unity Editor 'playmode'. " +
            "Use '" + EditorApplicationGetStateToolId + "' to inspect the current state first. " +
            "Throws if the project currently has compilation errors.")]
        [AiSkillBody("Control the Unity Editor application state. " +
            "You can start, stop, or pause the 'playmode'. " +
            "Use '" + EditorApplicationGetStateToolId + "' tool to get the current state first.\n\n" +
            "## Inputs\n\n" +
            "- `isPlaying` (default `false`) — sets `EditorApplication.isPlaying`.\n" +
            "- `isPaused` (default `false`) — sets `EditorApplication.isPaused`.\n\n" +
            "## Behavior\n\n" +
            "Refuses any state change while `EditorUtility.scriptCompilationFailed` is true — instead throws with " +
            "the compilation error details so the caller can fix them first. On success returns the post-change " +
            "`EditorStatsData` snapshot.")]
        [Description("Control the Unity Editor application state. " +
            "You can start, stop, or pause the 'playmode'. " +
            "Use '" + EditorApplicationGetStateToolId + "' tool to get the current state first.")]
        public EditorStatsData? SetApplicationState
        (
            [Description("If true, the 'playmode' will be started. If false, the 'playmode' will be stopped.")]
            bool isPlaying = false,
            [Description("If true, the 'playmode' will be paused. If false, the 'playmode' will be resumed.")]
            bool isPaused = false
        )
        {
            return MainThread.Instance.Run(() =>
            {
                if (UnityEditor.EditorUtility.scriptCompilationFailed)
                {
                    var compilationErrorDetails = ScriptUtils.GetCompilationErrorDetails();
                    throw new Exception($"Unity project has compilation error. Please fix all compilation errors before doing this operation.\n{compilationErrorDetails}");
                }
                EditorApplication.isPlaying = isPlaying;
                EditorApplication.isPaused = isPaused;

                return EditorStatsData.FromEditor();
            });
        }
    }
}
