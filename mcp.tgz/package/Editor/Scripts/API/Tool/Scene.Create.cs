/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
using System.ComponentModel;
using com.IvanMurzak.McpPlugin;
using com.IvanMurzak.ReflectorNet.Utils;
using com.IvanMurzak.Unity.MCP.Editor.Utils;
using AIGD;

namespace com.IvanMurzak.Unity.MCP.Editor.API
{
    public partial class Tool_Scene
    {
        public const string SceneCreateToolId = "scene-create";
        [AiTool
        (
            SceneCreateToolId,
            Title = "Scene / Create"
        )]
        [AiSkillDescription("Create a new Unity scene asset and save it at the given `.unity` path. " +
            "Use '" + SceneListOpenedToolId + "' to inspect the resulting opened-scene set afterwards.")]
        [AiSkillBody("Create new scene in the project assets. " +
            "Use '" + SceneListOpenedToolId + "' tool to list all opened scenes after creation.\n\n" +
            "## Inputs\n\n" +
            "- `path` — must end with `.unity`. Non-empty.\n" +
            "- `newSceneSetup` (default `DefaultGameObjects`) — Unity's `NewSceneSetup` flag (`EmptyScene` or `DefaultGameObjects`).\n" +
            "- `newSceneMode` (default `Single`) — `Single` closes other scenes, `Additive` keeps them open.\n\n" +
            "## Behavior\n\n" +
            "Calls `EditorSceneManager.NewScene` + `SaveScene(path)` on the main thread, repaints editor windows, " +
            "and returns a `SceneDataShallow` for the newly created scene.")]
        [Description("Create new scene in the project assets. " +
            "Use '" + SceneListOpenedToolId + "' tool to list all opened scenes after creation.")]
        public SceneDataShallow Create
        (
            [Description("Path to the scene file. Should end with \".unity\" extension.")]
            string path,
            UnityEditor.SceneManagement.NewSceneSetup? newSceneSetup = UnityEditor.SceneManagement.NewSceneSetup.DefaultGameObjects,
            UnityEditor.SceneManagement.NewSceneMode? newSceneMode = UnityEditor.SceneManagement.NewSceneMode.Single
        )
        {
            return MainThread.Instance.Run(() =>
            {
                if (string.IsNullOrEmpty(path))
                    throw new System.Exception(Error.ScenePathIsEmpty());

                if (!path.EndsWith(".unity"))
                    throw new System.Exception(Error.FilePathMustEndsWithUnity());

                // Create a new empty scene
                var scene = UnityEditor.SceneManagement.EditorSceneManager.NewScene(
                    newSceneSetup ?? UnityEditor.SceneManagement.NewSceneSetup.DefaultGameObjects,
                    newSceneMode ?? UnityEditor.SceneManagement.NewSceneMode.Single);

                // Save the scene asset at the specified path
                bool saved = UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene, path);
                if (!saved)
                    throw new System.Exception($"Failed to save scene at '{path}'.\n{OpenedScenesText}");

                EditorUtils.RepaintAllEditorWindows();

                return scene.ToSceneDataShallow();
            });
        }
    }
}
