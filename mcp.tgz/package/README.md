<div align="center" width="100%">
  <h1>✨ AI Game Developer — <i>Unity SKILLS, MCP</i></h1>

[![MCP](https://badge.mcpx.dev 'MCP Server')](https://modelcontextprotocol.io/introduction)
[![OpenUPM](https://img.shields.io/npm/v/com.ivanmurzak.unity.mcp?label=OpenUPM&registry_uri=https://package.openupm.com&labelColor=333A41 'OpenUPM package')](https://openupm.com/packages/com.ivanmurzak.unity.mcp/)
[![Docker Image](https://img.shields.io/docker/image-size/ivanmurzakdev/unity-mcp-server/latest?label=Docker%20Image&logo=docker&labelColor=333A41 'Docker Image')](https://hub.docker.com/r/ivanmurzakdev/unity-mcp-server)
[![Unity Editor](https://img.shields.io/badge/Editor-X?style=flat&logo=unity&labelColor=333A41&color=2A2A2A 'Unity Editor supported')](https://unity.com/releases/editor/archive)
[![Unity Runtime](https://img.shields.io/badge/Runtime-X?style=flat&logo=unity&labelColor=333A41&color=2A2A2A 'Unity Runtime supported')](https://unity.com/releases/editor/archive)
[![r](https://github.com/IvanMurzak/Unity-MCP/workflows/release/badge.svg 'Tests Passed')](https://github.com/IvanMurzak/Unity-MCP/actions/workflows/release.yml)</br>
[![Discord](https://img.shields.io/badge/Discord-Join-7289da?logo=discord&logoColor=white&labelColor=333A41 'Join')](https://discord.gg/cfbdMZX99G)
[![OpenUPM](https://img.shields.io/badge/dynamic/json?labelColor=333A41&label=Downloads&query=%24.downloads&suffix=%2Fmonth&url=https%3A%2F%2Fpackage.openupm.com%2Fdownloads%2Fpoint%2Flast-month%2Fcom.ivanmurzak.unity.mcp)](https://openupm.com/packages/com.ivanmurzak.unity.mcp/)
[![Stars](https://img.shields.io/github/stars/IvanMurzak/Unity-MCP 'Stars')](https://github.com/IvanMurzak/Unity-MCP/stargazers)
[![License](https://img.shields.io/github/license/IvanMurzak/Unity-MCP?label=License&labelColor=333A41)](https://github.com/IvanMurzak/Unity-MCP/blob/main/LICENSE)
[![Stand With Ukraine](https://raw.githubusercontent.com/vshymanskyy/StandWithUkraine/main/badges/StandWithUkraine.svg)](https://stand-with-ukraine.pp.ua)

  <img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/promo/ai-developer-banner.jpg" alt="AI work" title="Level building" width="100%">

  <p>
    <a href="https://claude.ai/download"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/claude-64.png" alt="Claude" title="Claude" height="36"></a>&nbsp;&nbsp;
    <a href="https://openai.com/index/introducing-codex/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/codex-64.png" alt="Codex" title="Codex" height="36"></a>&nbsp;&nbsp;
    <a href="https://www.cursor.com/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/cursor-64.png" alt="Cursor" title="Cursor" height="36"></a>&nbsp;&nbsp;
    <a href="https://code.visualstudio.com/docs/copilot/overview"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/github-copilot-64.png" alt="GitHub Copilot" title="GitHub Copilot" height="36"></a>&nbsp;&nbsp;
    <a href="https://gemini.google.com/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/gemini-64.png" alt="Gemini" title="Gemini" height="36"></a>&nbsp;&nbsp;
    <a href="https://antigravity.google/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/antigravity-64.png" alt="Antigravity" title="Antigravity" height="36"></a>&nbsp;&nbsp;
    <a href="https://code.visualstudio.com/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/vs-code-64.png" alt="VS Code" title="VS Code" height="36"></a>&nbsp;&nbsp;
    <a href="https://www.jetbrains.com/rider/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/rider-64.png" alt="Rider" title="Rider" height="36"></a>&nbsp;&nbsp;
    <a href="https://visualstudio.microsoft.com/"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/visual-studio-64.png" alt="Visual Studio" title="Visual Studio" height="36"></a>&nbsp;&nbsp;
    <a href="https://github.com/anthropics/claude-code"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/open-code-64.png" alt="Open Code" title="Open Code" height="36"></a>&nbsp;&nbsp;
    <a href="https://github.com/cline/cline"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/cline-64.png" alt="Cline" title="Cline" height="36"></a>&nbsp;&nbsp;
    <a href="https://github.com/Kilo-Org/kilocode"><img src="https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/mcp-clients/kilo-code-64.png" alt="Kilo Code" title="Kilo Code" height="36"></a>
  </p>

  <b>[中文](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/README.zh-CN.md) | [日本語](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/README.ja.md) | [Español](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/README.es.md)</b>

</div>

`Unity MCP` is an AI-powered game development assistant **for Editor & Runtime**. Connect **Claude**, **Cursor**, & **Windsurf** to Unity via MCP. Automate workflows, generate code, and **enable AI within your games**.

Unlike other tools, this plugin works **inside your compiled game**, allowing for real-time AI debugging and player-AI interaction.

> **[💬 Join our Discord Server](https://discord.gg/cfbdMZX99G)** - Ask questions, showcase your work, and connect with other developers!

## ![AI Game Developer — Unity MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-features.svg?raw=true)

- ✔️ **AI agents** - Use the best agents from **Anthropic**, **OpenAI**, **Microsoft**, or any other provider with no vendor lock-in
- ✔️ **Tools** - A wide range of default [MCP Tools](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/default-mcp-tools.md) for operating in Unity Editor
- ✔️ **Skills** - Generate skills for AI based on operating system, Unity version, plugins in the project
- ✔️ **Code and Tests** - Develop game mechanics and test them with AI agents
- ✔️ **Runtime (in-game)** - Use LLMs directly inside your compiled game for dynamic NPC behavior or debugging
- ✔️ **Debug support** - Let AI debug and fix the problems in a project
- ✔️ **Natural conversation** - Chat with AI like you would with a human
- ✔️ **Flexible deployment** - Works locally (stdio) and remotely (http) via configuration
- ✔️ **Extensible** - [Create custom Tools in your project code](#add-custom-tool)

[![DOWNLOAD INSTALLER](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/button/button_download.svg?raw=true)](https://github.com/IvanMurzak/Unity-MCP/releases/latest/download/AI-Game-Dev-Installer.unitypackage)

https://github.com/user-attachments/assets/228baf4d-4f00-4dce-939d-fb985ebdd8dd

### OR use cli

```bash
# 1. Install unity-mcp-cli
npm install -g unity-mcp-cli

# 2. Install "AI Game Developer" in Unity project
unity-mcp-cli install-plugin ./MyUnityProject

# 3. Login to cloud server
unity-mcp-cli login ./MyUnityProject

# 4. Open Unity project (auto-connects and generates skills)
unity-mcp-cli open ./MyUnityProject
```

![AI Game Developer Windows](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/editor/ai-game-developer-windows.png?raw=true)

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Quick Start

Get up and running in three steps:

1. **[Install plugin](#step-1-install-unity-mcp-plugin)** — download the `.unitypackage` installer or run `openupm add com.ivanmurzak.unity.mcp`
   > **Alternative:** `npx unity-mcp-cli install-plugin ./MyUnityProject` — see [CLI documentation](https://github.com/IvanMurzak/Unity-MCP/blob/main/cli/README.md)
2. **[Pick an AI agent](#step-2-install-ai-agent)** — Claude Code, Claude Desktop, GitHub Copilot, Cursor, or any other
3. **[Setup AI agent](#step-3-configure-ai-agent)** — open `Window/AI Game Developer` in Unity and click **Auto-generate skills** (recommended) or **Configure MCP**
  ![Setup AI Skills](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/editor/setup-skills.jpg?raw=true)
   > **Alternative:** `npx unity-mcp-cli setup-skills claude-code ./MyUnityProject` — see [CLI documentation](https://github.com/IvanMurzak/Unity-MCP/blob/main/cli/README.md)


That's it. Ask your AI *"Create 3 cubes in a circle with radius 2"* and watch it happen. ✨

---

# Skills and Tools Reference

The plugin ships with 100+ built-in tools across three categories. Each tool brings AI skill. All tools are available immediately after installation — no extra configuration required. See [docs/default-mcp-tools.md](docs/default-mcp-tools.md) for the full reference with detailed descriptions.

<details>
  <summary>Project & Assets</summary>

- `assets-copy` - Copy the asset at path and stores it at newPath
- `assets-create-folder` - Creates a new folder in the specified parent folder
- `assets-delete` - Delete the assets at paths from the project
- `assets-find` - Search the asset database using the search filter string
- `assets-find-built-in` - Search the built-in assets of the Unity Editor
- `assets-get-data` - Get asset data from the asset file including all serializable fields and properties
- `assets-material-create` - Create new material asset with default parameters
- `assets-modify` - Modify asset file in the project
- `assets-move` - Move the assets at paths in the project (also used for rename)
- `assets-prefab-close` - Close currently opened prefab
- `assets-prefab-create` - Create a prefab from a GameObject in the current active scene
- `assets-prefab-instantiate` - Instantiates prefab in the current active scene
- `assets-prefab-open` - Open prefab edit mode for a specific GameObject
- `assets-prefab-save` - Save a prefab in prefab editing mode
- `assets-refresh` - Refreshes the AssetDatabase
- `assets-shader-list-all` - List all available shaders in the project assets and packages
- `package-add` - Install a package from the Unity Package Manager registry, Git URL, or local path
- `package-list` - List all packages installed in the Unity project (UPM packages)
- `package-remove` - Remove (uninstall) a package from the Unity project
- `package-search` - Search for packages in both Unity Package Manager registry and installed packages

</details>

<details>
  <summary>Scene & Hierarchy</summary>

- `gameobject-component-add` - Add Component to GameObject
- `gameobject-component-destroy` - Destroy one or many components from target GameObject
- `gameobject-component-get` - Get detailed information about a specific Component on a GameObject
- `gameobject-component-list-all` - List C# class names extended from UnityEngine.Component
- `gameobject-component-modify` - Modify a specific Component on a GameObject
- `gameobject-create` - Create a new GameObject in opened Prefab or in a Scene
- `gameobject-destroy` - Destroy GameObject and all nested GameObjects recursively
- `gameobject-duplicate` - Duplicate GameObjects in opened Prefab or in a Scene
- `gameobject-find` - Finds specific GameObject by provided information
- `gameobject-modify` - Modify GameObjects and/or attached component's fields and properties
- `gameobject-set-parent` - Set parent GameObject to list of GameObjects
- `object-get-data` - Get data of the specified Unity Object
- `object-modify` - Modify the specified Unity Object
- `scene-create` - Create new scene in the project assets
- `scene-get-data` - Retrieves the list of root GameObjects in the specified scene
- `scene-list-opened` - Returns the list of currently opened scenes in Unity Editor
- `scene-open` - Open scene from the project asset file
- `scene-save` - Save opened scene to the asset file
- `scene-set-active` - Set the specified opened scene as the active scene
- `scene-unload` - Unload scene from the opened scenes in Unity Editor
- `screenshot-camera` - Captures a screenshot from a camera and returns it as an image
- `screenshot-game-view` - Captures a screenshot from the Unity Editor Game View
- `screenshot-scene-view` - Captures a screenshot from the Unity Editor Scene View

</details>

<details>
  <summary>Scripting & Editor</summary>

- `console-get-logs` - Retrieves Unity Editor logs with filtering options
- `editor-application-get-state` - Returns information about the Unity Editor application state (playmode, paused, compilation)
- `editor-application-set-state` - Control the Unity Editor application state (start/stop/pause playmode)
- `editor-selection-get` - Get information about the current Selection in the Unity Editor
- `editor-selection-set` - Set the current Selection in the Unity Editor
- `reflection-method-call` - Call any C# method with input parameters and return results
- `reflection-method-find` - Find method in the project using C# Reflection (even private methods)
- `script-delete` - Delete the script file(s)
- `script-execute` - Compiles and executes C# code dynamically using Roslyn
- `script-read` - Reads the content of a script file
- `script-update-or-create` - Updates or creates script file with the provided C# code
- `tests-run` - Execute Unity tests (EditMode/PlayMode) with filtering and detailed results

</details>

## Install Additional Skills and Tools

Install extensions when need more tools or [create your own tools](#add-custom-tool).

| Extension | Description |
| --- | --- |
| **[AI Animation](https://github.com/IvanMurzak/Unity-AI-Animation/)** | Set of additional tools for Unity Animations |
| **[AI ParticleSystem](https://github.com/IvanMurzak/Unity-AI-ParticleSystem/)** | Set of additional tools for Unity Particle System |
| **[AI ProBuilder](https://github.com/IvanMurzak/Unity-AI-ProBuilder/)** | Set of additional tools for Unity ProBuilder |

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Contents

- [Quick Start](#quick-start)
- [Skills and Tools Reference](#skills-and-tools-reference)
  - [Install Additional Skills and Tools](#install-additional-skills-and-tools)
- [Contents](#contents)
  - [More Documentation](#more-documentation)
- [Installation](#installation)
  - [Step 1: Install `Unity MCP Plugin`](#step-1-install-unity-mcp-plugin)
    - [Option 1 - Installer](#option-1---installer)
    - [Option 2 - CLI (recommended)](#option-2---cli-recommended)
  - [Step 2: Install `AI agent`](#step-2-install-ai-agent)
  - [Step 3: Configure `AI agent`](#step-3-configure-ai-agent)
    - [Automatic configuration](#automatic-configuration)
    - [Manual configuration](#manual-configuration)
      - [Command line configuration](#command-line-configuration)
- [AI Workflow Examples](#ai-workflow-examples)
  - [Advanced Features for LLM](#advanced-features-for-llm)
    - [Core Capabilities](#core-capabilities)
    - [Reflection-Powered Features](#reflection-powered-features)
- [Customize Tools](#customize-tools)
  - [Add custom `Tool`](#add-custom-tool)
  - [Add custom `MCP Prompt`](#add-custom-mcp-prompt)
- [Runtime usage (in-game)](#runtime-usage-in-game)
  - [Sample: AI powered Chess game bot](#sample-ai-powered-chess-game-bot)
  - [Why runtime usage is needed?](#why-runtime-usage-is-needed)
- [Unity `MCP Server` setup](#unity-mcp-server-setup)
  - [Variables](#variables)
  - [Plugin Variables](#plugin-variables)
  - [Docker 📦](#docker-)
    - [`streamableHttp` Transport](#streamablehttp-transport)
    - [`stdio` Transport](#stdio-transport)
    - [Custom `port`](#custom-port)
  - [Binary executable](#binary-executable)
- [How Unity MCP Architecture Works](#how-unity-mcp-architecture-works)
  - [What is `MCP`](#what-is-mcp)
  - [What is `AI agent`](#what-is-ai-agent)
  - [What is `MCP Server`](#what-is-mcp-server)
  - [What is `MCP Tool`](#what-is-mcp-tool)
    - [When to use `Tool`](#when-to-use-tool)
  - [What is `MCP Resource`](#what-is-mcp-resource)
    - [When to use `MCP Resource`](#when-to-use-mcp-resource)
  - [What is `MCP Prompt`](#what-is-mcp-prompt)
    - [When to use `MCP Prompt`](#when-to-use-mcp-prompt)
- [Contribution 💙💛](#contribution-)

## More Documentation

| Document | Description |
| -------- | ----------- |
| [Default MCP Tools](docs/default-mcp-tools.md) | Full reference of all built-in tools with descriptions |
| [MCP Server Setup](docs/mcp-server.md) | Server configuration, environment variables, remote hosting |
| [Docker Deployment](docs/DOCKER_DEPLOYMENT.md) | Step-by-step Docker deployment guide |
| [Development Guide](docs/dev/Development.md) | Architecture, code style, CI/CD — for contributors |
| [Wiki](https://github.com/IvanMurzak/Unity-MCP/wiki) | Getting started, tutorials, API reference, FAQ |
| [CLI Tool](https://github.com/IvanMurzak/Unity-MCP/blob/main/cli/README.md) | Install plugins, configure, and connect via command line |

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Installation

## Step 1: Install `Unity MCP Plugin`

<details>
  <summary><b>⚠️ Requirements (click)</b></summary>

> [!IMPORTANT]
> **Project path cannot contain spaces**
>
> - ✅ `C:/MyProjects/MyProject`
> - ❌ `C:/My Projects/MyProject`
> - ❌ `C:/My Projects/My Project`
> - ❌ `C:/MyProjects/My Project`

</details>

### Option 1 - Installer

- **[⬇️ Download Installer](https://github.com/IvanMurzak/Unity-MCP/releases/latest/download/AI-Game-Dev-Installer.unitypackage)**
- **📂 Import installer into Unity project**
  > - You can double-click on the file - Unity will open it automatically
  > - OR: Open Unity Editor first, then click on `Assets/Import Package/Custom Package`, and choose the file

### Option 2 - CLI (recommended)

Install the plugin via [`unity-mcp-cli`](https://github.com/IvanMurzak/Unity-MCP/blob/main/cli/README.md) — no Unity Editor needed:

```bash
# 1.1 Install unity-mcp-cli                                #  ┌────────────────────┐
npm install -g unity-mcp-cli                               #  │ Available AI agent │
                                                           #  ├────────────────────┤
# 1.2 (Optional) Install Unity                             #  │ antigravity        │
unity-mcp-cli install-unity                                #  │ claude-code        │
                                                           #  │ claude-desktop     │
# 1.3 (Optional) Create Unity project                      #  │ cline              │
unity-mcp-cli create-project ./MyUnityProject              #  │ codex              │
                                                           #  │ cursor             │
# 2. Install "AI Game Developer" in Unity project          #  │ gemini             │
unity-mcp-cli install-plugin ./MyUnityProject              #  │ github-copilot-cli │
                                                           #  │ kilo-code          │
# 3. Login to cloud server                                 #  │ open-code          │
unity-mcp-cli login ./MyUnityProject                       #  │ rider-junie        │
                                                           #  │ unity-ai           │
# 4. Open Unity project (auto-connects and generates skills)  │ vs-copilot         │
unity-mcp-cli open ./MyUnityProject                        #  │ vscode-copilot     │
                                                           #  └────────────────────┘
# 5. Wait for Unity Editor to be ready
unity-mcp-cli wait-for-ready ./MyUnityProject
```

> See [full CLI documentation](https://github.com/IvanMurzak/Unity-MCP/blob/main/cli/README.md) for all available commands.

## Step 2: Install `AI agent`

Choose a single `AI agent` you prefer - you don't need to install all of them. This will be your main chat window to communicate with the LLM.

- [Claude Code](https://github.com/anthropics/claude-code) **(recommended)**
- [Claude Desktop](https://claude.ai/download)
- [GitHub Copilot in VS Code](https://code.visualstudio.com/docs/copilot/overview)
- [Antigravity](https://antigravity.google/)
- [Cursor](https://www.cursor.com/)
- [Windsurf](https://windsurf.com)
- Any other supported

> The AI Game Developer is quite universal, which is why you may use any AI agent you prefer - it will work as smoothly as any other. The only important requirement is that the AI agent must support Skills or dynamic MCP Tool updates.

## Step 3: Configure `AI agent`

### Automatic configuration

- Open Unity project
- Open `Window/AI Game Developer`
- Option 1: Click `Auto-generate` Skills **(recommended)**
- Option 2: Click `Configure` Model Context Protocol (MCP)

![Unity_AI](https://github.com/IvanMurzak/Unity-MCP/raw/main/docs/img/ai-connector-window.gif)

> If your MCP client is not in the list, use the raw JSON shown in the window to inject it into your MCP client. Read the instructions for your specific MCP client on how to do this.

### Manual configuration

If automatic configuration doesn't work for you for any reason, use the JSON from the `AI Game Developer (Unity-MCP)` window to configure any `MCP Client` manually.

#### Command line configuration

<details>
  <summary><b>Create <code>command</code></b></summary>

**1. Choose your `<command>` for your environment**

| Platform            | `<command>`                                                                                                 |
| ------------------- | ----------------------------------------------------------------------------------------------------------- |
| Windows x64         | `"<unityProjectPath>/Library/mcp-server/win-x64/unity-mcp-server.exe" port=<port> client-transport=stdio`   |
| Windows x86         | `"<unityProjectPath>/Library/mcp-server/win-x86/unity-mcp-server.exe" port=<port> client-transport=stdio`   |
| Windows arm64       | `"<unityProjectPath>/Library/mcp-server/win-arm64/unity-mcp-server.exe" port=<port> client-transport=stdio` |
| MacOS Apple-Silicon | `"<unityProjectPath>/Library/mcp-server/osx-arm64/unity-mcp-server" port=<port> client-transport=stdio`     |
| MacOS Apple-Intel   | `"<unityProjectPath>/Library/mcp-server/osx-x64/unity-mcp-server" port=<port> client-transport=stdio`       |
| Linux x64           | `"<unityProjectPath>/Library/mcp-server/linux-x64/unity-mcp-server" port=<port> client-transport=stdio`     |
| Linux arm64         | `"<unityProjectPath>/Library/mcp-server/linux-arm64/unity-mcp-server" port=<port> client-transport=stdio`   |

**2. Replace `<unityProjectPath>` with the full path to Unity project**

**3. Replace `<port>` with your port from AI Game Developer configuration**

**4. Add MCP server using command line**

</details>

<details>
  <summary><img src="https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/mcp-clients/gemini-64.png?raw=true" width="16" height="16" alt="Gemini CLI"> Gemini CLI</summary>

  ```bash
  gemini mcp add ai-game-developer <command>
  ```

  > Replace `<command>` from the table above
</details>

<details>
  <summary><img src="https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/mcp-clients/claude-64.png?raw=true" width="16" height="16" alt="Claude Code CLI"> Claude Code CLI</summary>

  ```bash
  claude mcp add ai-game-developer <command>
  ```

  > Replace `<command>` from the table above
</details>

<details>
  <summary><img src="https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/mcp-clients/github-copilot-64.png?raw=true" width="16" height="16" alt="GitHub Copilot CLI"> GitHub Copilot CLI</summary>

  ```bash
  copilot
  ```

  ```bash
  /mcp add
  ```

  Server name: `ai-game-developer`
  Server type: `local`
  Command: `<command>`
  > Replace `<command>` from the table above
</details>

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# AI Workflow Examples

Communicate with the AI (LLM) in your `AI agent`. Ask it to do anything you want. The better you describe your task or idea, the better it will perform the job.

Some `AI agents` allow you to choose different LLM models. Pay attention to this feature, as some models may work much better than others.

**Example prompts:**

```text
Explain my scene hierarchy
```

```text
Create 3 spheres on top of each other
```

```text
Create metallic golden material and attach it to a new sphere gameObject
```

> Make sure `Agent` mode is enabled if using VS Code with Copilot

## Disabling update notifications for the whole team

The plugin shows an update popup at Editor startup when a newer version is available on OpenUPM. By default, each team member sees this popup until they individually click *"Do not show again"* (which is a per-user setting stored on their machine).

For multi-person Unity projects where one engineer owns plugin versioning, you can disable the popup for the **entire team** by opening **Edit ▸ Project Settings ▸ AI Game Developer** and enabling *"Disable update notifications for the entire team"*. The setting is persisted to `ProjectSettings/AI-Game-Developer-UpdateSettings.asset` and only needs to be set once per project — commit that file and every team member who pulls the commit will have the popup suppressed.

The same toggle is also reachable via **Tools ▸ AI Game Developer ▸ Updates ▸ Disable Update Notifications (Team)** in the menu bar.

## Advanced Features for LLM

Unity MCP provides advanced tools that enable the LLM to work faster and more effectively, avoiding mistakes and self-correcting when errors occur. Everything is designed to achieve your goals efficiently.

### Core Capabilities

- ✔️ **Agent-ready tools** - Find anything you need in 1-2 steps
- ✔️ **Instant compilation** - C# code compilation & execution using `Roslyn` for faster iteration
- ✔️ **Full asset access** - Read/write access to assets and C# scripts
- ✔️ **Intelligent feedback** - Well-described positive and negative feedback for proper issue understanding

### Reflection-Powered Features

- ✔️ **Object references** - Provide references to existing objects for instant C# code
- ✔️ **Project data access** - Get full access to entire project data in a readable format
- ✔️ **Granular modifications** - Populate & modify any piece of data in the project
- ✔️ **Method discovery** - Find any method in the entire codebase, including compiled DLL files
- ✔️ **Method execution** - Call any method in the entire codebase
- ✔️ **Advanced parameters** - Provide any property for method calls, even references to existing objects in memory
- ✔️ **Live Unity API** - Unity API instantly available - even when Unity changes, you get the fresh API
- ✔️ **Self-documenting** - Access human-readable descriptions of any `class`, `method`, or `property` via `Description` attributes

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Customize Tools

**[Unity MCP](https://github.com/IvanMurzak/Unity-MCP)** supports custom `MCP Tool`, `MCP Resource`, and `MCP Prompt` development by project owners. The MCP server takes data from the `Unity MCP Plugin` and exposes it to a client. Anyone in the MCP communication chain will receive information about new MCP features, which the LLM may decide to use at some point.

## Add custom `Tool`

To add a custom `Tool`, you need:

1. A class with the `McpPluginToolType` attribute
2. A method in the class with the `McpPluginTool` attribute
3. *Optional:* Add a `Description` attribute to each method argument to help the LLM understand it
4. *Optional:* Use `string? optional = null` properties with `?` and default values to mark them as `optional` for the LLM

> Note that the line `MainThread.Instance.Run(() =>` allows you to run code on the main thread, which is required for interacting with Unity's API. If you don't need this and running the tool in a background thread is acceptable, avoid using the main thread for efficiency purposes.

```csharp
[McpPluginToolType]
public class Tool_GameObject
{
    [McpPluginTool
    (
        "MyCustomTask",
        Title = "Create a new GameObject"
    )]
    [Description("Explain here to LLM what is this, when it should be called.")]
    public string CustomTask
    (
        [Description("Explain to LLM what is this.")]
        string inputData
    )
    {
        // do anything in background thread

        return MainThread.Instance.Run(() =>
        {
            // do something in main thread if needed

            return $"[Success] Operation completed.";
        });
    }
}
```

## Add custom `MCP Prompt`

`MCP Prompt` allows you to inject custom prompts into the conversation with the LLM. It supports two sender roles: User and Assistant. This is a quick way to instruct the LLM to perform specific tasks. You can generate prompts using custom data, providing lists or any other relevant information.

```csharp
[McpPluginPromptType]
public static class Prompt_ScriptingCode
{
    [McpPluginPrompt(Name = "add-event-system", Role = Role.User)]
    [Description("Implement UnityEvent-based communication system between GameObjects.")]
    public string AddEventSystem()
    {
        return "Create event system using UnityEvents, UnityActions, or custom event delegates for decoupled communication between game systems and components.";
    }
}
```

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Runtime usage (in-game)

Use **[Unity MCP](https://github.com/IvanMurzak/Unity-MCP)** in your game/app. Use Tools, Resources or Prompts. By default there are no tools, you would need to implement your custom.

```csharp
// Build MCP plugin
var mcpPlugin = UnityMcpPluginRuntime.Initialize(builder =>
    {
        builder.WithConfig(config =>
        {
            config.Host = "http://localhost:8080";
            config.Token = "your-token";
        });
        // Automatically register all tools from the current assembly
        builder.WithToolsFromAssembly(Assembly.GetExecutingAssembly());
    })
    .Build();

await mcpPlugin.Connect(); // Start active connection with retry to Unity-MCP-Server

await mcpPlugin.Disconnect(); // Stop active connection and close existed connection
```

## Sample: AI powered Chess game bot

There is a classic Chess game. Lets outsource to LLM the bot logic. Bot should do the turn using game rules.

```csharp
[McpPluginToolType]
public static class ChessGameAI
{
    [McpPluginTool("chess-do-turn", Title = "Do the turn")]
    [Description("Do the turn in the chess game. Returns true if the turn was accepted, false otherwise.")]
    public static Task<bool> DoTurn(int figureId, Vector2Int position)
    {
        return MainThread.Instance.RunAsync(() => ChessGameController.Instance.DoTurn(figureId, position));
    }

    [McpPluginTool("chess-get-board", Title = "Get the board")]
    [Description("Get the current state of the chess board.")]
    public static Task<BoardData> GetBoard()
    {
        return MainThread.Instance.RunAsync(() => ChessGameController.Instance.GetBoardData());
    }
}
```

## Why runtime usage is needed?

There are many use cases, lets imagine you are working on a Chess game with bot. You may outsource the bot decision making to LLM by writing few lines of code.

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Unity `MCP Server` setup

**[Unity MCP](https://github.com/IvanMurzak/Unity-MCP)** Server supports many different launch options and Docker deployment. Both transport protocols are supported: `streamableHttp` and `stdio`. If you need to customize or deploy Unity MCP Server to a cloud, this section is for you. [Read more...](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/mcp-server.md)

## Variables

Doesn't matter what launch option you choose, all of them support custom configuration using both Environment Variables and Command Line Arguments. It would work with default values, if you just need to launch it, don't waste your time for the variables. Just make sure Unity Plugin also has default values, especially the `--port`, they should be equal.

| Environment Variable         | Command Line Args    | Description                                                                  |
| ---------------------------- | -------------------- | ---------------------------------------------------------------------------- |
| `MCP_PLUGIN_PORT`            | `--port`             | **Client** -> **Server** <- **Plugin** connection port (default: 8080)       |
| `MCP_PLUGIN_CLIENT_TIMEOUT`   | `--plugin-timeout`   | **Plugin** -> **Server** connection timeout (ms) (default: 10000)            |
| `MCP_PLUGIN_CLIENT_TRANSPORT` | `--client-transport` | **Client** -> **Server** transport type: `stdio` or `streamableHttp` (default: `streamableHttp`) |

> Command line args support also the option with a single `-` prefix (`-port`) and an option without prefix at all (`port`).

> **Choosing a transport:** Use `stdio` when the MCP client launches the server binary directly (local use — this is the most common setup). Use `streamableHttp` when running the server as a standalone process or in Docker/cloud, and connecting over HTTP.

## Plugin Variables

The Unity MCP Plugin reads the following environment variables (and command-line arguments) on startup to override values from the saved config file. Overrides are applied at runtime; on first run or when a new authentication token is generated, the overridden values are **written to the config file**. On subsequent runs, overrides are applied in memory but are not automatically saved. The exception is `UNITY_MCP_TOOLS`, which uses `[JsonIgnore]` and is **never persisted** — it is runtime-only.

| Environment Variable        | Command Line Arg            | Values              | Description                                   |
| --------------------------- | --------------------------- | ------------------- | --------------------------------------------- |
| `UNITY_MCP_HOST`            | `-UNITY_MCP_HOST`           | URL string                    | Override the MCP Server host URL                                    |
| `UNITY_MCP_KEEP_CONNECTED`  | `-UNITY_MCP_KEEP_CONNECTED` | `true` / `false`              | Force enable or disable the active connection                       |
| `UNITY_MCP_AUTH_OPTION`     | `-UNITY_MCP_AUTH_OPTION`    | `none` / `required`           | Force set the authentication mode                                   |
| `UNITY_MCP_TOKEN`           | `-UNITY_MCP_TOKEN`          | string                        | Force set the authentication token                                  |
| `UNITY_MCP_TOOLS`           | `-UNITY_MCP_TOOLS`          | comma-separated tool IDs      | Enable only the listed tools; all others are disabled. Unknown IDs are logged as errors. |

> Command-line args take precedence over environment variables. Both override the saved config file value.

**Example (CI/CD batch mode):**

```bash
Unity.exe -batchmode -nographics \
  -UNITY_MCP_HOST=http://localhost:8080 \
  -UNITY_MCP_KEEP_CONNECTED=true \
  -UNITY_MCP_AUTH_OPTION=required \
  -UNITY_MCP_TOKEN=my-secret-token
```

## Docker 📦

[![Docker Image](https://img.shields.io/docker/image-size/ivanmurzakdev/unity-mcp-server/latest?label=Docker%20Image&logo=docker&labelColor=333A41 'Docker Image')](https://hub.docker.com/r/ivanmurzakdev/unity-mcp-server)

Make sure Docker is installed. And please make sure Docker Desktop is launched if you are at Windows operation system.

[Read advanced Docker configuration instructions](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/DOCKER_DEPLOYMENT.md).

### `streamableHttp` Transport

```bash
docker run -p 8080:8080 ivanmurzakdev/unity-mcp-server
```

<details>
  <summary><code>MCP Client</code> config:</summary>

```json
{
  "mcpServers": {
    "ai-game-developer": {
      "url": "http://localhost:8080"
    }
  }
}
```

> Replace `url` with your real endpoint if it is hosted in cloud.

</details>

### `stdio` Transport

For using this variant, `MCP Client` should launch the `MCP Server` in the docker. It is achievable through the modified `MCP Client` configuration.

```bash
docker run -t -e MCP_PLUGIN_CLIENT_TRANSPORT=stdio -p 8080:8080 ivanmurzakdev/unity-mcp-server
```

<details>
  <summary><code>MCP Client</code> config:</summary>

```json
{
  "mcpServers": {
    "ai-game-developer": {
      "command": "docker",
      "args": [
        "run",
        "-t",
        "-e",
        "MCP_PLUGIN_CLIENT_TRANSPORT=stdio",
        "-p",
        "8080:8080",
        "ivanmurzakdev/unity-mcp-server"
      ]
    }
  }
}
```

</details>

### Custom `port`

```bash
docker run -e MCP_PLUGIN_PORT=123 -p 123:123 ivanmurzakdev/unity-mcp-server
```

<details>
  <summary><code>MCP Client</code> config:</summary>

```json
{
  "mcpServers": {
    "ai-game-developer": {
      "url": "http://localhost:123"
    }
  }
}
```

> Replace `url` with your real endpoint if it is hosted in cloud
</details>

## Binary executable

You may launch Unity `MCP Server` directly from a binary file. You would need to have a binary compiled specifically for your CPU architecture. Check [GitHub Release Page](https://github.com/IvanMurzak/Unity-MCP/releases), it contains pre-compiled binaries for all CPU architectures.

```bash
./unity-mcp-server --port 8080 --plugin-timeout 10000 --client-transport stdio
```

<details>
  <summary><code>MCP Client</code> config:</summary>

> Replace `<project>` with your Unity project path.

```json
{
  "mcpServers": {
    "ai-game-developer": {
      "command": "<project>/Library/mcp-server/win-x64/unity-mcp-server.exe",
      "args": [
        "--port=8080",
        "--plugin-timeout=10000",
        "--client-transport=stdio"
      ]
    }
  }
}
```

</details>

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# How Unity MCP Architecture Works

**[Unity MCP](https://github.com/IvanMurzak/Unity-MCP)** serves as a bridge between LLMs and Unity. It exposes and explains Unity's tools to the LLM, which then understands the interface and utilizes the tools according to user requests.

Connect **[Unity MCP](https://github.com/IvanMurzak/Unity-MCP)** to LLM clients such as [Claude](https://claude.ai/download) or [Cursor](https://www.cursor.com/) using the integrated `AI Connector` window. Custom clients are also supported.

The system is highly extensible - you can define custom `MCP Tools`, `MCP Resource` or `MCP Prompt` directly in your Unity project codebase, exposing new capabilities to AI or automation clients. This makes Unity MCP a flexible foundation for building advanced workflows, rapid prototyping, and integrating AI-driven features into your development process.

## What is `MCP`

MCP - Model Context Protocol. In a few words, that is `USB Type-C` for AI, specifically for LLM (Large Language Model). It teaches LLM how to use external features. Such as Unity Engine in this case, or even your custom C# method in your code. [Official documentation](https://modelcontextprotocol.io/).

## What is `AI agent`

It is an application with a chat window. It may have smart agents to operate better, it may have embedded advanced MCP Tools. In general well done MCP Client is 50% of the AI success of executing a task. That is why it is very important to choose the best one for usage.

## What is `MCP Server`

It is a bridge between `MCP Client` and "something else", in this particular case it is Unity Engine. This project includes `MCP Server`.

## What is `MCP Tool`

`MCP Tool` is a function or method that the LLM can call to interact with Unity. These tools act as the bridge between natural language requests and actual Unity operations. When you ask the AI to "create a cube" or "change material color," it uses MCP Tools to execute these actions.

**Key characteristics:**

- **Executable functions** that perform specific operations
- **Typed parameters** with descriptions to help the LLM understand what data to provide
- **Return values** that give feedback about the operation's success or failure
- **Thread-aware** - can run on main thread for Unity API calls or background thread for heavy processing

### When to use `Tool`

- **Automate repetitive tasks** - Create tools for common operations you do frequently
- **Complex operations** - Bundle multiple Unity API calls into a single, easy-to-use tool
- **Project-specific workflows** - Build tools that understand your project's specific structure and conventions
- **Error-prone tasks** - Create tools that include validation and error handling
- **Custom game logic** - Expose your game's systems to AI for dynamic content creation

**Examples:**

- Creating and configuring GameObjects with specific components
- Batch processing assets (textures, materials, prefabs)
- Setting up lighting and post-processing effects
- Generating level geometry or placing objects procedurally
- Configuring physics settings or collision layers

## What is `MCP Resource`

`MCP Resource` provides read-only access to data within your Unity project. Unlike MCP Tools that perform actions, Resources allow the LLM to inspect and understand your project's current state, assets, and configuration. Think of them as "sensors" that give the AI context about your project.

**Key characteristics:**

- **Read-only access** to project data and Unity objects
- **Structured information** presented in a format the LLM can understand
- **Real-time data** that reflects the current state of your project
- **Contextual awareness** helping the AI make informed decisions

### When to use `MCP Resource`

- **Project analysis** - Let AI understand your project structure, assets, and organization
- **Debugging assistance** - Provide current state information for troubleshooting
- **Intelligent suggestions** - Give AI context to make better recommendations
- **Documentation generation** - Automatically create documentation based on project state
- **Asset management** - Help AI understand what assets are available and their properties

**Examples:**

- Exposing scene hierarchy and GameObject properties
- Listing available materials, textures, and their settings
- Showing script dependencies and component relationships
- Displaying current lighting setup and render pipeline configuration
- Providing information about audio sources, animations, and particle systems

## What is `MCP Prompt`

`MCP Prompt` allows you to inject pre-defined prompts into the conversation with the LLM. These are smart templates that can provide context, instructions, or knowledge to guide the AI's behavior. Prompts can be static text or dynamically generated based on your project's current state.

**Key characteristics:**

- **Contextual guidance** that influences how the AI responds
- **Role-based** - can simulate different personas (User requests or Assistant knowledge)
- **Dynamic content** - can include real-time project data
- **Reusable templates** for common scenarios and workflows

### When to use `MCP Prompt`

- **Provide domain knowledge** - Share best practices and coding standards specific to your project
- **Set coding conventions** - Establish naming conventions, architecture patterns, and code style
- **Give context about project structure** - Explain how your project is organized and why
- **Share workflow instructions** - Provide step-by-step procedures for common tasks
- **Inject specialized knowledge** - Add information about specific Unity features, third-party assets, or custom systems

**Examples:**

- "Always use PascalCase for public methods and camelCase for private fields"
- "This project uses a custom event system located in Scripts/Events/"
- "When creating UI elements, always add them to the Canvas in Scene/UI/MainCanvas"
- "Performance is critical - prefer object pooling for frequently instantiated objects"
- "This project follows SOLID principles - explain any architecture decisions"

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)

# Contribution 💙💛

Contributions are highly appreciated. Bring your ideas and let's make game development simpler than ever before! Do you have an idea for a new `Tool` or feature, or did you spot a bug and know how to fix it?

**Please give this project a star 🌟 if you find it useful!**

1. 👉 [Read Development documentation](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/dev/Development.md)
2. 👉 [Fork the project](https://github.com/IvanMurzak/Unity-MCP/fork)
3. Clone the fork and open the `./Unity-MCP-Plugin` folder in Unity
4. Implement new things in the project, commit, push it to GitHub
5. Create Pull Request targeting original [Unity-MCP](https://github.com/IvanMurzak/Unity-MCP/compare) repository, `main` branch.

![AI Game Developer — Unity SKILLS and MCP](https://github.com/IvanMurzak/Unity-MCP/blob/main/docs/img/promo/hazzard-divider.svg?raw=true)
