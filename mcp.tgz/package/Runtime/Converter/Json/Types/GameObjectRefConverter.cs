/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
#if UNITY_6000_5_OR_NEWER
using System;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using com.IvanMurzak.McpPlugin;
using com.IvanMurzak.ReflectorNet;
using com.IvanMurzak.ReflectorNet.Utils;
using AIGD;

namespace com.IvanMurzak.Unity.MCP.JsonConverters
{
    public class GameObjectRefConverter : JsonConverter<GameObjectRef>
    {
        public override GameObjectRef? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType == JsonTokenType.Null)
                return null;

            if (reader.TokenType != JsonTokenType.StartObject)
                throw new JsonException("Expected start of object token.");

            var result = new GameObjectRef();

            while (reader.Read())
            {
                if (reader.TokenType == JsonTokenType.EndObject)
                    return result;

                if (reader.TokenType == JsonTokenType.PropertyName)
                {
                    var propertyName = reader.GetString();
                    reader.Read(); // Move to the value token

                    switch (propertyName)
                    {
                        case ObjectRef.ObjectRefProperty.InstanceID:
                            result.InstanceID = EntityIdConverter.ReadEntityIdValue(ref reader);
                            break;
                        case GameObjectRef.GameObjectRefProperty.Path:
                            result.Path = reader.GetString();
                            break;
                        case GameObjectRef.GameObjectRefProperty.Name:
                            result.Name = reader.GetString();
                            break;
                        case AssetObjectRef.AssetObjectRefProperty.AssetType:
                            result.AssetType = TypeUtils.GetType(reader.GetString());
                            break;
                        case AssetObjectRef.AssetObjectRefProperty.AssetPath:
                            result.AssetPath = reader.GetString();
                            break;
                        case AssetObjectRef.AssetObjectRefProperty.AssetGuid:
                            result.AssetGuid = reader.GetString();
                            break;
                        default:
                            throw new JsonException($"Unexpected property name: {propertyName}. "
                                + $"Expected {GameObjectRef.GameObjectRefProperty.All.JoinEnclose()}.");
                    }
                }
            }

            throw new JsonException("Expected end of object token.");
        }

        public override void Write(Utf8JsonWriter writer, GameObjectRef value, JsonSerializerOptions options)
        {
            if (value == null)
            {
                writer.WriteStartObject();

                // Write the "instanceID" property — see EntityIdConverter
                // top-of-file wire contract (#759): outbound is always a
                // JSON string of decimal digits, never a number.
                writer.WriteString(ObjectRef.ObjectRefProperty.InstanceID, "0");

                writer.WriteEndObject();
                return;
            }

            writer.WriteStartObject();

            // Write the "instanceID" property (JSON string — see #759).
            writer.WriteString(ObjectRef.ObjectRefProperty.InstanceID, UnityEngine.EntityId.ToULong(value.InstanceID).ToString(CultureInfo.InvariantCulture));

            if (!string.IsNullOrEmpty(value.Path))
                writer.WriteString(GameObjectRef.GameObjectRefProperty.Path, value.Path);

            if (!string.IsNullOrEmpty(value.Name))
                writer.WriteString(GameObjectRef.GameObjectRefProperty.Name, value.Name);

            if (value.AssetType != null)
                writer.WriteString(AssetObjectRef.AssetObjectRefProperty.AssetType, value.AssetType.GetTypeId());

            if (!string.IsNullOrEmpty(value.AssetPath))
                writer.WriteString(AssetObjectRef.AssetObjectRefProperty.AssetPath, value.AssetPath);

            if (!string.IsNullOrEmpty(value.AssetGuid))
                writer.WriteString(AssetObjectRef.AssetObjectRefProperty.AssetGuid, value.AssetGuid);

            writer.WriteEndObject();
        }
    }
}
#endif
